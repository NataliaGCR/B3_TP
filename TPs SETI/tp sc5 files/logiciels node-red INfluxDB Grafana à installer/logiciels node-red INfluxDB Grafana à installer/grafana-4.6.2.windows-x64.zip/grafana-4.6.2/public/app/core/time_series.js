define([
  './time_series2'
], function(timeSeries) {
  'use strict';
  // backward compatability hack;
  return timeSeries.default;
});
